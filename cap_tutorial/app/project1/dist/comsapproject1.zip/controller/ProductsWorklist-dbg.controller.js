sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
], function (Controller, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("com.sap.project1.controller.ProductsWorklist", {
    });
});